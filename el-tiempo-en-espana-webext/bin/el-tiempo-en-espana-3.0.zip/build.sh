#!/bin/bash

zip -r ../el-tiempo-en-espana.xpi *
